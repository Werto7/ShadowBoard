<?php
$lang_common = array(
//Fehlermeldung
'Forum error header'		=> 'Entschuldigung! Die Seite konnte nicht geladen werden.',
'Forum error description'	=> 'Dies ist wahrscheinlich ein vorübergehender Fehler. Aktualisieren Sie einfach die Seite und versuchen Sie es erneut. Wenn das Problem weiterhin besteht, versuchen Sie es bitte in 5–10 Minuten erneut.',
);
?>